package warmup;

import java.util.HashSet;
import java.util.Set;

public class Quadratic {

    /**
     * Find the integer roots of a quadratic equation, ax^2 + bx + c = 0.
     *
     * @param a coefficient of x^2
     * @param b coefficient of x
     * @param c constant term.  Requires that a, b, and c are not ALL zero.
     * @return all integers x such that ax^2 + bx + c = 0.
     */
    public static Set<Integer> roots(int a, int b, int c) {

        if (a == 0 && b == 0 && c == 0) {
            throw new IllegalArgumentException();
        }

        Set<Integer> roots = new HashSet<>();

        if (b == 0) {

            if (c < 0 || a < 0) {
                c = -c;
            }

            int solution = (int) Math.sqrt(c / a);

            roots.add(solution);
            roots.add(-solution);
            return roots;
        }

        if (c == 0) {
            roots.add(0);
            roots.add(-b/a);
            return roots;
        }

        int discriminant = (b * b - 4 * a * c);

        int discriminantRoot = (int) Math.sqrt(discriminant);

        roots.add((-b - discriminantRoot) / (2 * a));
        roots.add((-b + discriminantRoot) / (2 * a));

        return roots;
    }

    /**
     * Main function of program.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        int r1 =  45_000; // a root ~45,000 means c is ~2,000,000,000, which is close to the maximum integer 2^31 - 1
        int r2 = -45_000;

        System.out.println(-r1-r2);
        System.out.println(r1*r2);
        System.out.println(Math.sqrt(-r1*r2));
        Set<Integer> result = Quadratic.roots(1, -r1-r2, r1*r2);
        System.out.println(result);
    }

    /* Copyright (c) 2016 MIT 6.005 course staff, all rights reserved.
     * Redistribution of original or derived work requires explicit permission.
     * Don't post any of this code on the web or to a public Github repository.
     */
}
